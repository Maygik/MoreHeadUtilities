# PartRemovers

Adds cosmetics to MoreHead allowing for parts to be removed

This is primarily a demonstration of my [MoreHeadUtilities](https://thunderstore.io/c/repo/p/Maygik/MoreHeadUtilities/) mod

## How to use

1. Select the cosmetics through the MoreHead menu

![MoreHeadMenu](https://raw.githubusercontent.com/Maygik/MoreHeadUtilities/refs/heads/master/Shared/MoreHeadMenu.png)


## Patch Notes
	-v1.0.3
		- Added group support for MoreHeadUtilities
	-v1.0.2
		- Added Pupil removers
	-v1.0.1
		- Added Eye removers
	-v1.0.0
		- Initial Upload